/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inputOutput;

/**
 *
 * @author Dillon
 */
public interface IReadDataFile {
    
    // method to read a data file and populate as ArrayList
    public void populateData();
}
